package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import dto.EmployeeDTO;
import entity.EmployeeEntity;

public class EmployeeDAO {
	
	public void addEmployee(EmployeeDTO emp)
	{
	
		//Entity manager Factory
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa1");
		//Entity Manager
		EntityManager em=emf.createEntityManager();
		EmployeeEntity entity=new EmployeeEntity();
		//entity.setEmpId(emp.getEmpid());
		entity.setCity(emp.getCity());
		entity.setSalary(emp.getSalary());
		entity.setEmpName(emp.getEmpName());
		entity.setDoj(emp.getOdj());
		 EntityTransaction et=  em.getTransaction();
		 et.begin();
		em.persist(entity);
		em.close();
		emf.close();
		et.commit();
		System.out.println("inserted");
	}
	public void getEmployee(int id)
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa1");
		//Entity Manager
		EntityManager em=emf.createEntityManager();
		EmployeeEntity entity=em.find(EmployeeEntity.class,id);
		if(entity==null)
		{
			System.out.println("record not found");
		}
		System.out.println(entity.getEmpName()+" "+entity.getSalary()+" "+entity.getCity());
		
		em.close();
		emf.close();
		System.out.println("fetched");
	}
	public EmployeeDTO updateEmployee( int id,String newCity)
	{
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa1");
		//Entity Manager
		EntityManager em=emf.createEntityManager();
		EmployeeEntity entity=em.find(EmployeeEntity.class,id);
		 EntityTransaction et=  em.getTransaction();
		 et.begin();
	entity.setCity(newCity);
		em.close();
		emf.close();
		et.commit();
		EmployeeDTO emp=new EmployeeDTO();
		emp.setCity(entity.getCity());
		emp.setEmpid(entity.getEmpId());
		emp.setEmpName(entity.getEmpName());
		emp.setOdj(entity.getDoj());
		emp.setSalary(entity.getSalary());
		return emp;
	}
	public void deleteEmployee(int id)
	{
		
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa1");
		//Entity Manager
		EntityManager em=emf.createEntityManager();
		EmployeeEntity entity=em.find(EmployeeEntity.class,id);
		 EntityTransaction et=  em.getTransaction();
		
		 et.begin();
		 em.remove(entity);
			et.commit();
		 
		em.close();
		emf.close();
		System.out.println("deleted");
	}
	

}

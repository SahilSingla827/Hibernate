package service;

import dao.EmployeeDAO;
import dto.EmployeeDTO;

public class EmployeeService {

	public void addEmployee(EmployeeDTO emp)
	{
		new EmployeeDAO().addEmployee(emp);
	}
	public void getEmployee(int id)
	{
		new EmployeeDAO().getEmployee(id);
	}
	public EmployeeDTO updateEmployee( int id,String newCity)
	{
		 return new EmployeeDAO().updateEmployee(id,newCity);
	}
	public void deleteEmployee(int id)
	{
		new EmployeeDAO().deleteEmployee(id);
	}
}
